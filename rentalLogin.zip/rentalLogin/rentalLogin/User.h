#pragma once
using namespace System;

public ref class User {
public:
	int id;
	String^ name;
	String^ phone;
	String^ email;
	String^ address;
	String^ gender;
	String^ password;
};