#pragma once
using namespace System;

public ref class CustomerModel {
public:
	String^ opt;
	String^ name;
	String^ dl;
	String^ adr;
	String^ pn;
	String^ price;
};