#pragma once
#include "CustomerModel.h"
#include "MainForm.h"
namespace rentalLogin {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;
	using namespace System::Data::SqlClient;

	/// <summary>
	/// Summary for Customer
	/// </summary>
	public ref class CustomerForm : public System::Windows::Forms::Form
	{
	public:
		CustomerForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CustomerForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::TextBox^ tbName;
	private: System::Windows::Forms::TextBox^ tbDL;
	private: System::Windows::Forms::TextBox^ tbAdr;
	private: System::Windows::Forms::TextBox^ tbPN;
	private: System::Windows::Forms::TextBox^ tbPrice;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::TextBox^ tbOption;
	private: System::Windows::Forms::Panel^ panel1;
	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Panel^ panel3;
	private: System::Windows::Forms::Panel^ panel4;
	private: System::Windows::Forms::Panel^ panel5;
	private: System::Windows::Forms::Panel^ panel6;






	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(CustomerForm::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->tbName = (gcnew System::Windows::Forms::TextBox());
			this->tbDL = (gcnew System::Windows::Forms::TextBox());
			this->tbAdr = (gcnew System::Windows::Forms::TextBox());
			this->tbPN = (gcnew System::Windows::Forms::TextBox());
			this->tbPrice = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->tbOption = (gcnew System::Windows::Forms::TextBox());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->panel3 = (gcnew System::Windows::Forms::Panel());
			this->panel4 = (gcnew System::Windows::Forms::Panel());
			this->panel5 = (gcnew System::Windows::Forms::Panel());
			this->panel6 = (gcnew System::Windows::Forms::Panel());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 24, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::Control;
			this->label1->Location = System::Drawing::Point(168, 115);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(356, 37);
			this->label1->TabIndex = 0;
			this->label1->Text = L"CUSTOMER DETAILS";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::Control;
			this->label2->Location = System::Drawing::Point(171, 260);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(76, 26);
			this->label2->TabIndex = 1;
			this->label2->Text = L"NAME";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::Transparent;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::SystemColors::Control;
			this->label3->Location = System::Drawing::Point(171, 319);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(197, 26);
			this->label3->TabIndex = 2;
			this->label3->Text = L"DRIVER LICENSE";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::Transparent;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::SystemColors::Control;
			this->label4->Location = System::Drawing::Point(171, 373);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(120, 26);
			this->label4->TabIndex = 3;
			this->label4->Text = L"ADDRESS";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::Transparent;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::SystemColors::Control;
			this->label5->Location = System::Drawing::Point(171, 425);
			this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(130, 26);
			this->label5->TabIndex = 4;
			this->label5->Text = L"PHONE NO";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::Transparent;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::SystemColors::Control;
			this->label6->Location = System::Drawing::Point(171, 493);
			this->label6->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(138, 26);
			this->label6->TabIndex = 5;
			this->label6->Text = L"PRICE PAID";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(247, 577);
			this->button1->Margin = System::Windows::Forms::Padding(4);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(211, 59);
			this->button1->TabIndex = 6;
			this->button1->Text = L"OK";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &CustomerForm::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(587, 577);
			this->button2->Margin = System::Windows::Forms::Padding(4);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(211, 59);
			this->button2->TabIndex = 7;
			this->button2->Text = L"CANCEL";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &CustomerForm::button2_Click);
			// 
			// tbName
			// 
			this->tbName->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->tbName->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tbName->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tbName->ForeColor = System::Drawing::SystemColors::Control;
			this->tbName->Location = System::Drawing::Point(402, 268);
			this->tbName->Margin = System::Windows::Forms::Padding(4);
			this->tbName->Name = L"tbName";
			this->tbName->Size = System::Drawing::Size(421, 25);
			this->tbName->TabIndex = 8;
			// 
			// tbDL
			// 
			this->tbDL->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->tbDL->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tbDL->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tbDL->ForeColor = System::Drawing::SystemColors::Control;
			this->tbDL->Location = System::Drawing::Point(402, 327);
			this->tbDL->Margin = System::Windows::Forms::Padding(4);
			this->tbDL->Name = L"tbDL";
			this->tbDL->Size = System::Drawing::Size(421, 25);
			this->tbDL->TabIndex = 9;
			// 
			// tbAdr
			// 
			this->tbAdr->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->tbAdr->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tbAdr->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tbAdr->ForeColor = System::Drawing::SystemColors::Control;
			this->tbAdr->Location = System::Drawing::Point(402, 381);
			this->tbAdr->Margin = System::Windows::Forms::Padding(4);
			this->tbAdr->Name = L"tbAdr";
			this->tbAdr->Size = System::Drawing::Size(421, 25);
			this->tbAdr->TabIndex = 10;
			// 
			// tbPN
			// 
			this->tbPN->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->tbPN->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tbPN->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tbPN->ForeColor = System::Drawing::SystemColors::Control;
			this->tbPN->Location = System::Drawing::Point(402, 433);
			this->tbPN->Margin = System::Windows::Forms::Padding(4);
			this->tbPN->Name = L"tbPN";
			this->tbPN->Size = System::Drawing::Size(421, 25);
			this->tbPN->TabIndex = 11;
			// 
			// tbPrice
			// 
			this->tbPrice->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->tbPrice->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tbPrice->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tbPrice->ForeColor = System::Drawing::SystemColors::Control;
			this->tbPrice->Location = System::Drawing::Point(402, 501);
			this->tbPrice->Margin = System::Windows::Forms::Padding(4);
			this->tbPrice->Name = L"tbPrice";
			this->tbPrice->Size = System::Drawing::Size(421, 25);
			this->tbPrice->TabIndex = 12;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::Transparent;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::SystemColors::Control;
			this->label7->Location = System::Drawing::Point(171, 206);
			this->label7->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(187, 26);
			this->label7->TabIndex = 13;
			this->label7->Text = L"OPTION(buy/rent)";
			// 
			// tbOption
			// 
			this->tbOption->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(35)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->tbOption->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tbOption->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->tbOption->ForeColor = System::Drawing::SystemColors::Control;
			this->tbOption->Location = System::Drawing::Point(402, 214);
			this->tbOption->Margin = System::Windows::Forms::Padding(4);
			this->tbOption->Name = L"tbOption";
			this->tbOption->Size = System::Drawing::Size(421, 25);
			this->tbOption->TabIndex = 14;
			// 
			// panel1
			// 
			this->panel1->Location = System::Drawing::Point(402, 251);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(421, 2);
			this->panel1->TabIndex = 15;
			// 
			// panel2
			// 
			this->panel2->Location = System::Drawing::Point(402, 304);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(421, 2);
			this->panel2->TabIndex = 16;
			// 
			// panel3
			// 
			this->panel3->Location = System::Drawing::Point(402, 364);
			this->panel3->Name = L"panel3";
			this->panel3->Size = System::Drawing::Size(421, 2);
			this->panel3->TabIndex = 17;
			// 
			// panel4
			// 
			this->panel4->Location = System::Drawing::Point(402, 416);
			this->panel4->Name = L"panel4";
			this->panel4->Size = System::Drawing::Size(421, 2);
			this->panel4->TabIndex = 18;
			// 
			// panel5
			// 
			this->panel5->Location = System::Drawing::Point(402, 470);
			this->panel5->Name = L"panel5";
			this->panel5->Size = System::Drawing::Size(421, 2);
			this->panel5->TabIndex = 19;
			// 
			// panel6
			// 
			this->panel6->Location = System::Drawing::Point(402, 536);
			this->panel6->Name = L"panel6";
			this->panel6->Size = System::Drawing::Size(421, 2);
			this->panel6->TabIndex = 20;
			// 
			// CustomerForm
			// 
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::None;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(1262, 673);
			this->Controls->Add(this->panel6);
			this->Controls->Add(this->panel5);
			this->Controls->Add(this->panel4);
			this->Controls->Add(this->panel3);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->tbOption);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->tbPrice);
			this->Controls->Add(this->tbPN);
			this->Controls->Add(this->tbAdr);
			this->Controls->Add(this->tbDL);
			this->Controls->Add(this->tbName);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->ForeColor = System::Drawing::SystemColors::Control;
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"CustomerForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"Customer";
			this->Load += gcnew System::EventHandler(this, &CustomerForm::CustomerForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	public: CustomerModel^ customer = nullptr;

	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ option = this->tbOption->Text;
		String^ name = this->tbName->Text;
		String^ dl = this->tbDL->Text;
		String^ adr = this->tbAdr->Text;
		String^ pn = this->tbPN->Text;
		String^ price = this->tbPrice->Text;

		String^ connString = L"Data Source=localhost\\sqlexpress;Initial Catalog=test;Integrated Security=True";
		SqlConnection sqlCon(connString);
		sqlCon.Open();
		String^ sqlQuery = "INSERT INTO customer(opt, name, dl, address, pn, price) VALUES (@opt, @name, @dl, @adr, @pn, @price);";
		SqlCommand command(sqlQuery, % sqlCon);

		command.Parameters->AddWithValue("@opt", option);
		command.Parameters->AddWithValue("@name", name);
		command.Parameters->AddWithValue("@dl", dl);
		command.Parameters->AddWithValue("@adr", adr);
		command.Parameters->AddWithValue("@pn", pn);
		command.Parameters->AddWithValue("@price", price);
		SqlDataReader^ reader = command.ExecuteReader();

		customer = gcnew CustomerModel;
		customer->opt = option;
		customer->name = name;
		customer->dl = dl;
		customer->adr = adr;
		customer->pn = pn;
		customer->price = price;

		this->Close();

		if (option == "buy") {
			MessageBox::Show("SUCCESSFULLY BOUGHT THE CAR", "CONGRATUALTIONS", MessageBoxButtons::OK);
		}
		else {
			MessageBox::Show("SUCCESSFULLY RENTED THE CAR", "CONGRATULATION", MessageBoxButtons::OK);
		}
	}
		  public: bool customerToMain = false;
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		this->customerToMain = true;
		this->Close();
	}
private: System::Void CustomerForm_Load(System::Object^ sender, System::EventArgs^ e) {
}
};
}
