﻿SET IDENTITY_INSERT [dbo].[users] ON
INSERT INTO [dbo].[users] ([Id], [name], [phone], [email], [address], [gender], [password]) VALUES (1, N'Hrithik', N'9960471659', N'hrithik@gmail.com', N'Pune', N'Male', N'hrithik')
INSERT INTO [dbo].[users] ([Id], [name], [phone], [email], [address], [gender], [password]) VALUES (2, N'Mrunal', N'7785426598', N'mrunal@gmail.com', N'Bangalore', N'Male', N'mrunal')
INSERT INTO [dbo].[users] ([Id], [name], [phone], [email], [address], [gender], [password]) VALUES (3, N'Sakshi', N'7785462316', N'sakshi@gmail.com', N'Mumbai', N'Female', N'sakshi')
INSERT INTO [dbo].[users] ([Id], [name], [phone], [email], [address], [gender], [password]) VALUES (4, N'Devansh', N'5113997512', N'devansh@gmail.com', N'Chennai', N'Male', N'devansh')
INSERT INTO [dbo].[users] ([Id], [name], [phone], [email], [address], [gender], [password]) VALUES (5, N'Chethan', N'9865751367', N'chethan@gmail.com', N'Delhi', N'Male', N'chethan')
SET IDENTITY_INSERT [dbo].[users] OFF